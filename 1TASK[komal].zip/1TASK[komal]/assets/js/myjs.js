function toggle(){
    var blur=document.getElementById('blur');
    blur.classList.toggle('active')
    var pop=document.getElementById('focus');
    pop.classList.toggle('active')
}



